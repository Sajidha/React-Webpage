import React from 'react';
import Navigation from './components/Navigation';
import LoginForm from './components/LoginForm';

class Root extends React.Component {

	constructor(props) {
		super(props);

		this.state = {
			user: null
		}
	}

	Login(username, password) {
	    this.setState({
	      user: {
	        username,
	        password,
	      }
	    })
	  }

	Logout() {
		this.setState({
			user: null
		})
	}
	

	

	render() {
		const Welcome = (user, OnLogout) => {
			return <div className="welcome-tag">Welcome <strong>{user.username}</strong>!
				      <a href="javascript:;" onClick={OnLogout}>Sign out</a>
				    </div>
		}

		return(
			<div className="header">
				<Navigation />

				{ 
		          (this.state.user) ? 
		            <Welcome 
		             user={this.state.user} 
		             OnLogout={this.Logout.bind(this)} 
		            />
		          :
		            <LoginForm 
		             OnLogin={this.Login.bind(this)}
		            />
		        }
			</div>
		)
	}
}

export default Root