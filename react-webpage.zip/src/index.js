import React from 'react';
import ReactDOM from 'react-dom';
import {BrowserRouter, Route, Redirect} from "react-router-dom";
import './index.css';
import Root from './Root';
import Home from './components/Home';
import About from './components/About';
import Services from './components/Services';
import Contact from './components/Contact';
import ProductList from './components/ProductList';
import productPage from './components/productPage';
import Navigation from './components/Navigation';
import registerServiceWorker from './registerServiceWorker';

ReactDOM.render(
	<BrowserRouter>
		<div>
		    <Route path='/' component={Root} />
		    <Route exact path='/' component={Home} />
		    <Route exact path='/home' component={Home} />
		    <Route exact path="/about" component={About} />
		    <Route exact path='/services' component={Services} />
		    <Route exact path='/contact' component={Contact} />
		    <Route exact path='/productlist' component={ProductList} />
		    <Route exact path='/product/:id' component={productPage} />
	    </div>
    </BrowserRouter>,
document.getElementById('root'));
registerServiceWorker();