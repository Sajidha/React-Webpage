import React from 'react';
import LoginForm from './LoginForm';

class Contact extends React.Component {

	render() {
		return(
			<div className="clearfix padT50">
				<h2>Contact</h2>
				<LoginForm />
			</div>
		)
	}
}

export default Contact