import React from 'react';
import LoginForm from './LoginForm';

class Services extends React.Component {

	function initMap() {
        var uluru = {lat: -25.363, lng: 131.044};
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 4,
          center: uluru
        });
        var marker = new google.maps.Marker({
          position: uluru,
          map: map
        });
      }

	render() {
		return(
			<div className="clearfix padT50">
				<h2>Services</h2>
				<LoginForm />

			</div>
		)
	}
}

export default Services