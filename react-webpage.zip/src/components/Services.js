import React from 'react';
import LoginForm from './LoginForm';

class Services extends React.Component {

	render() {
		return(
			<div className="clearfix padT50">
				<h2>Services</h2>
				<LoginForm />

			</div>
		)
	}
}

export default Services