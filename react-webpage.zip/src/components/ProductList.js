import React, { Component } from 'react';
import data from './data.json';
import { Link } from 'react-router-dom';

class ProductList extends React.Component {  

  render() {
    var rows = data.map(function(row){
        
      return (
        <Link to={'product/'+row.productId} text={"Hi"}>
          <div className="col-md-3 col-sm-6 col-xs-12 padB40" align="center">
            <img src={require(`./images/${row.productImage}`)} className="img-responsive img-shadow" alt="" />
            <h4 className="subtitle">{row.productBrand}</h4>
            <p>{row.productTitle}</p>
          </div>
        </Link>
        )
       });

    return (
        <div className="container">
            <h2 className="title">{this.props.title}</h2>            
            {rows}
        </div>
    );
  }
}

export default ProductList;